# Changelog

All notable changes to the **PocketGull Font Superfamily** will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html) (`v4.0.0`).

## [4.0.0] - 2026-11-09

### Added
- **Native OpenType `liga` Ligatures & Superfamily `GPOS` Kerning**:
  - Added `GSUB` LookupType 4 standard ligatures (`fi`, `fl`) across proportional superfamily cuts and injected GID-sorted `GPOS` `PairPos` kerning into `PocketGull-CondensedBold`, `PocketGull-Micro`, `PocketGull-MarkerRaw`, `PocketGull-Algo`, and `PocketGull-Genome`.
- **Clinical-Safe Default `Il1` Disambiguation in Base `cmap`**:
  - Upgraded base `U+006C` (`l`) across proportional humanist cuts and `PocketGull-VF.ttf` (with full 16-axis `gvar` continuity) to feature an unmistakable rightward curved clinical foot alongside bilateral serifed `U+0049` (`I`), eliminating `1 / l / I` ambiguity out of the box even without CSS `cv05`/`ss02`.
- **ISO 15008 Telemetry Gate, `avar`, & `FeatureParams` (`v3.1.3`–`v4.0.0`)**:
  - Unified all 39 cuts under no-space `'PocketGull'` naming, migrated CI to SHA-256-verified Rust `fontspector v1.9.0` (`0` `FAIL`s across `39/39` binaries + `5/5` `ISO 15008` telemetry pass), added `avar` & `ssXX`/`cvXX` UI labels, and synced 1:1 Z-layered SVGs across `asl_studio.html` & `sign_studio.html`.

### Changed
- **Canonical Dual-Licensing Clarity & Full SemVer `4.0.0` Synchronization**:
  - Standardized all 39 font binaries (`nameID 13/14`, `OFL.txt`, `METADATA.pb`) on **SIL Open Font License 1.1 (`OFL-1.1`)** and repository tooling/studios on **Apache License 2.0 (`LICENSE-APACHE-2.0.txt`)**.
  - Unified SemVer `4.0.0` (`head.fontRevision = 4.0`, `Version 4.000`) across all font binaries, Core WOFF2 subsets, R (`pocketgullr`), Quarto, Python (`pocketgull-math`), Typst, LaTeX, Homebrew, and web studios (`?v=4.0.0`).

## [3.1.2] - 2026-11-09

### Added
- **Z-Layered Anatomical ASL & Sign Language Engine (`PocketGull-ASL`, `Sign`, `Sign-VF`)**:
  - Redrew all 36 manual alphabet and numeral handshapes (`A–Z`, `0–9`) via a 2D Z-buffered Signed Distance Field + $C^1$ quadratic B-spline vectorizer with open white palmar counters, crisp foreground thumb/phalanx occlusion (`A, E, M, N, S, T`, `B` vs `4`, `6–9`), connected ulnar pinky (`I`), and unobstructed `J`/`Z` trajectory arrows.
- **Native OpenType `tnum` & `cv09` Layout Features**:
  - Injected native `tnum` (600 UPM / 460 UPM tabular numerals including `zero.slash.tnum`) and `cv09` (Philocardia heart-tittle `i` & `j`) `SingleSubst` lookups into `GSUB` across all superfamily cuts (with full `gvar`/`HVAR` synchronization on variable fonts).

### Fixed
- **Complete 62/62 Bold Serifs & `Serif-VF` Interpolation**:
  - Emboldened the remaining 37 ASCII glyphs in `PocketGull-Serif-Bold.ttf` via anisotropic outward normal offset, unlocking full 62/62 continuous `wght` (`400..700`) interpolation in `PocketGull-Serif-VF.ttf`.
- **Display-Scoped `PocketGull-Halftone.ttf` Optimization**:
  - Replaced 6,177 non-display exotic fallback halftone meshes with clean solid `PocketGull-Bold` outlines, cutting `PocketGull-Halftone.ttf` size by ~78% while preserving 100% of display halftone dots across Latin, Cyrillic, Greek, Numerals, Symbols, and Tactile Braille.
- **CI Fontbakery Profile Fix**:
  - Updated `.github/workflows/validate.yml` to run `fontbakery check-universal` cleanly without crashing on optional `shaperglot` imports.

## [3.1.1] - 2026-11-09

### Fixed
- **Variable Font `gvar` & `HVAR` Restoration (`PocketGull-VF`, `Serif-VF`, `Sign-VF`)**:
  - Restored all 8,603 active 16-axis `gvar` variation tuples into `PocketGull-VF.ttf` and `PocketGull-VF.woff2`, synthesized `O(1)` `HVAR` advance-width variation stores, populated all 16 `STAT` `DesignAxisRecord`s, added `nameID 25`, assigned unique `postscriptNameID`s, and pruned phantom Slab/Serif `fvar` instances.
  - Built live `wght` (`400..700`) `gvar` + `HVAR` tuples in `PocketGull-Serif-VF.ttf` and `PocketGullSerif[wght].ttf`, and restored live variations in `PocketGull-Sign-VF.ttf`.
- **OpenType Naming, Contour Geometry & Visual Completeness**:
  - Eliminated all CoreText / Font Book `nameID 1/4/6` collisions across `PocketGull-ASL`, `PocketGull-Soft`, `PocketGull-Serif-VF`, `PocketGull-Sign-VF`, and non-RIBBI subfamilies (`nameID 16/17` + RIBBI `nameID 1/2`), and standardized SIL OFL 1.1 metadata (`Version 3.101`).
  - Completed all 62/62 true-serif ASCII glyphs in `PocketGull-Serif-Regular.ttf`, rebuilt 151 clogged accented Latin-1/Ext-A diacritics + combining marks in `PocketGull-Outline.ttf` from clean hollow contours, and mapped lowercase `a–z` in `ASL`/`Sign` cuts to fingerspelling handshapes.
  - Normalized TrueType clockwise outer contour winding across static cuts, expanded `OS/2.usWinAscent`/`usWinDescent` to eliminate Windows vertical clipping, synchronized `OS/2.fsSelection` with `head.macStyle`, fixed `PocketGullMono-Italic` `caretSlope`, and aligned `scripts/package_release.py` and Homebrew Cask stanzas.

## [3.2.0] - 2026-09-27

### Added
- **OWASP Anti-Automation & Form Abuse Protection**:
  - Injected invisible anti-bot honeypots (`#formHpWebsite`) on sign consultation forms in `asl_studio.html` and `sign_studio.html`.
  - Added time-trap delays (`MIN_INTERACTION_MS = 1200ms`) and 4-second client rate-limiting cooldowns (`SUBMIT_COOLDOWN_MS = 4000ms`).
  - Enforced strict character length bounds (`maxlength="64"` for glyph review, `maxlength="2000"` for comments, `maxlength="300"` on Doc Drill socratic input in `index.html`).
  - Added control character sanitization (`[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]`) preventing header and URI injection in `mailto:` handlers.
  - Automated security regression test added to `test/security_and_ci_invariants.test.mjs`.
- **Salishan OpenType GPOS Mark & MKMK Anchor Definitions**:
  - Created standardized `features.fea` in UFO sources (`Bold`, `Fineliner`, `Chiseltip`, `Mono`) supporting canonical Salishan combining marks (`uni030C`, `uni0313`) anchored to base glyphs `x`, `q`, `k`, `c`, and `uni019B`.
  - Shaperglot feature proposal and audit dossier documented in `documentation/reports/`.
- **Osage Script Telemetry & Forensic Audit**:
  - Added Osage orthographic telemetry data (`fonts/case_study_osage_telemetry.json`) adhering to UNDRIP sovereign script standards.

### Fixed
- **Clean Glyph Geometry & TrueType 2-Byte Alignment**:
  - Removed duplicate on-curve nodes in `q.ejective_labial` and `k.ejective_labial` in `PocketGullMono-Regular.ttf`.
  - Re-synchronized all 146 production TrueType and WOFF2 binaries through the pure Dart foundry engine, achieving 100% W3C OTS memory safety (`loca[i] % 2 == 0`) and zero Google Fonts pre-flight errors.

## [3.100] - 2026-09-15

### Added
- **PocketGull Math Superfamily Member & OpenType Scientific Engine**:
  - Full OpenType `MATH` table architecture with 8,026 glyphs, 68 UPM robust vertical stems (preventing dark-mode hairline collapse), stepped delimiters (`.v1` to `.v4`), and optical sub/superscript kerning.
  - Procedural astronomical and celestial operators: Sun $\odot$ (`U+2299`, `U+2609`), Earth $\oplus$ (`U+2295`, `U+2641`), Jupiter $\jupiter$ (`U+2643`), Saturn $\saturn$ (`U+2644`), equilibrium harpoons $\rightleftharpoons$ (`U+21CC`, `U+21CB`), and reversible reaction arrow $\leftrightarrow$ (`U+2194`).
  - Strict 2-byte word boundary alignment (`loca[i] % 2 == 0`) and Bit-7 flag masking across all binaries.
- **Scientific, Astronomical & Mathematical Laboratory HUD (`index.html`)**:
  - Interactive **650nm Scotopic Red Mode** observatory console preserving human dark adaptation (rhodopsin) at deep-sky telescopes.
  - Real-time **Equatorial Coordinate Sliders** ($\alpha$ Right Ascension, $\delta$ Declination, $X$ Air Mass) driving live 80-column FITS standard header cards with zero column shear.
  - Interactive **Mathematical & Pharmacokinetics Formula Stage** showcasing $\mathcal{L}_{\mathrm{ASL}}$ quantile loss, Michaelis-Menten kinetics, two-compartment $C_p(t)$ bolus decay, and stepped brackets with OpenType feature switches.
- **PocketGull Live Terminal Telemetry CLI (`scripts/pocketgull_telemetry_cli.py`)**:
  - Real-time streaming terminal monitor supporting `--mode clinical`, `--mode astro`, and `--mode system`.
  - Sub-cell waveforms (`_/\_`, pleth bars), rounded box drawing, and zero-flicker differential ANSI updates.
- **Multi-Format Scientific Distribution Packages**:
  - **Matplotlib**: 4 production stylesheets (`pocketgull-dark`, `pocketgull-light`, `pocketgull-astro-night`, `pocketgull-bio`).
  - **Python / PyPI**: Hermetically built wheel and sdist (`pocketgull-math-3.1.0`).
  - **LaTeX / CTAN**: `pocketgull-math.sty` with keyval options and upload archive `pocketgull-math.zip` (1.2 MB).
  - **Typst Package Repository**: `@preview/pocketgull-math:3.1.0` with verified 800×600 PNG preview `thumbnail.png`.
  - **Quarto**: Scientific publishing extension and SCSS theme.
- **Global Package Registries Synchronization**:
  - Updated Homebrew Cask (`distribution/homebrew/font-pocketgull.rb`) and Windows Package Manager (`distribution/winget/PocketGull.Font.yaml`) with verified SHA256 checksums (`30a2d7de46e4b1391c528c63a3a7f7dfcc0df1c24160dff93e7d1d7422f3deca`).
  - Master release archive `PocketGull-v3.1.0-Superfamily.zip` (72.70 MB).

## [3.1.0] - 2026-09-06

### Added
- **Sumero-Akkadian Cuneiform Ancient Medicine & Hammurabi Clinical Codex**:
  - Full ingestion of 1,234 Unicode Sumero-Akkadian Cuneiform codepoints (`U+12000`–`U+12543`) across all proportional font cuts (`PocketGull-Regular`, `PocketGull-Bold`, `PocketGull-Black`, `PocketGull-Italic`, `PocketGull-BoldItalic`, `PocketGull-Fineliner`, `PocketGull-Chiseltip`).
  - Scaled and baseline-aligned all wedge stylus contours (vertical, horizontal, Winkelhaken) to match PocketGull's 714 UPM cap-height and Louise Sloan 5:1 optotype grid.
  - Decomposed nested composite components into pure simple glyphs to ensure 100% W3C OTS memory safety.
  - Interactive Cuneiform Clinical Codex showcase card and 203 DPI thermal prescription label simulation in `index.html`.
- **RTL Semitic Clinical Enhancement (Persian & Arabic)**:
  - Added dedicated Persian (Farsi: فارسی) clinical terminology (`فشار خون`, `قلب و مغز`, `دوز دارو`) and Perso-Arabic letter coverage (`پ`, `چ`, `ژ`, `گ`, `ک`, `ی`).
  - Added bedside thermal emergency prescriptions for Persian (`fa`) and Cuneiform (`cunei`).
  - Expanded RTL Semitic Card in `index.html` to a 3-column architecture grid (Arabic, Persian, Hebrew).

### Fixed
- **W3C OTS Memory Safety & Composite Maxp Recalculation**:
  - Stripped zero-contour empty component references (`NullMark` gid 3367) from Devanagari contextual glyphs (`uni093F0901.15`, `uni093F0930094D.15`, etc.), permanently resolving the browser console warning `glyf: empty gid 3367 used as component`.
  - Recalculated `maxp.maxCompositePoints` from 123 to 146 across all cuts, eliminating the browser console warning `glyf: Number of composite points in glyph 3297 exceeds maxp maxCompositePoints: 146 vs 123`.
  - Recompiled all 11 WOFF2 binaries and verified 0 console warnings or errors on live page reload.

## [3.0.0] - 2026-09-04

### Added
- **Tier 6 Indigenous & African Sovereign Scripts Full Release**:
  - **Canadian Aboriginal Syllabics (Inuktitut)** (`U+1400`–`U+167F`): 640 native codepoints (2,560 superfamily glyphs) preserving cardinal rotational geometry ($>30^\circ$ separation) and 120 UPM superdot clearance for Arctic telehealth and thermal wristband printing.
  - **Chinuk Pipa / Duployan Shorthand** (`U+1BC00`–`U+1BC9F`): 143 native codepoints (572 superfamily glyphs) preserving Father Le Jeune's 1891 *Kamloops Wawa* stenographic ductus and crossed saltire (`𛲟`, `U+1BC9F`) prescription delimiter.
  - **Neo-Tifinagh (Amazigh / Berber)** (`U+2D30`–`U+2D7F`): 59 native codepoints (236 superfamily glyphs) with IRCAM geometric symmetry and $\ge 140\text{ UPM}$ radial junction clearance.
  - **Cherokee Syllabary Traditional + Lowercase Supplement** (`U+13A0`–`U+13FF`, `U+AB70`–`U+ABBF`): 172 native codepoints (688 superfamily glyphs) with Sequoyan stroke modulation preventing Latin homoglyph confusion in Hastings Hospital MAR.
  - **Ethiopic / Ge'ez Abugida** (`U+1200`–`U+137F`): 358 native codepoints (1,432 superfamily glyphs) with 7-order vowel appendage heights ($\ge 150\text{ UPM}$) for 1-bit infusion pumps.
  - **Adlam (Pulaar / Fulani)** (`U+1E900`–`U+1E95F`): 88 native codepoints (352 superfamily glyphs) with UAX #9 BiDi numeric dosage isolation.
  - **Vai Syllabary** (`U+A500`–`U+A63F`): 300 native codepoints (1,200 superfamily glyphs) with $2:1$ stroke-to-counter ratio for complex 6-stroke syllabics.
  - **Total**: 1,760 assigned codepoints, 7,040 concrete font glyphs compiled across `PocketGull-Bold`, `PocketGull-Fineliner`, `PocketGull-Chiseltip`, and `PocketGullMono-Regular` in 73.88 s.
- **Fixed 600 UPM Monospace Advance Normalization**: All 1,760 Tier 6 codepoints in `PocketGullMono-Regular.ttf` normalized into rigid 600 UPM cells for streaming ICU telemetry and terminal EHR display with 0 layout jitter.
- **Interactive ISMP Clinical Safety Cards (8–11)**: Neo-Tifinagh, Cherokee, Ethiopic, and Adlam/Vai cards integrated into the live web showcase (`index.html`).
- **6 Peer-Reviewed Case Studies**: Published in `documentation/case_studies/` covering mathematical invariants, empirical acceleration factors ($>50,000\times$), and community health provenance.

### Changed
- **Total Character Set Expansion**:
  - `PocketGull-Bold.ttf`, `PocketGull-Fineliner.ttf`, `PocketGull-Chiseltip.ttf`: Expanded from 3,350 to **5,110 encoded Unicode points** (5,854 total glyphs).
  - `PocketGullMono-Regular.ttf`: Expanded from 3,763 to **5,523 encoded Unicode points** (5,781 total glyphs).
- **SemVer Milestone**: Promoted from SemVer 2.0.0 to **SemVer 3.0.0** marking the completion of Major World Script Tier 6.

### Fixed
- **Topological Outline Sanitization**: Zero duplicate nodes across all 7,040 compiled glyphs.
- **W3C OpenType Sanitizer (OTS)**: 100% memory-safe with 0 errors and 0 warnings.
- **Google Fonts Pre-Flight Verification**: 34 / 34 checks passed.

## [2.0.0] - 2026-09-03

### Added
- **Full Medical Terminal Glyphs (`PocketGullMono-Regular`)**: 17 Powerline chevrons, prompt anchors, and ICU status tags (`uniE0B0`–`uniE0B6`, `uniE0A0`–`uniE0A2`, `uni276F`, `uni276E`, `uni2714`, `uni2713`, `uni26A1`, `uni2300`, `uni271A`, `uni2695`) with exact 600 UPM fixed advance widths.
- **Complete 256-Glyph Unicode Braille Patterns Block (`U+2800`–`U+28FF`)**: Full ISO/TR 11548 tactile matrix support across all superfamily weights (`PocketGull-Bold`, `PocketGull-Fineliner`, `PocketGull-Chiseltip`, `PocketGullMono-Regular`).
- **OpenSSF Security Policy & Scorecard Integration**: Automated vulnerability reporting, Scorecard workflow, and SLSA provenance compliance.
- **Academic Citation Metadata (`CITATION.cff`)**: CFF 1.2.0 metadata for clinical informatics and ophthalmological literature.

### Changed
- **Standardized Version String (`nameID 5`)**: Updated to Google Fonts Option 5 Minimalist format: `Version 2.000; The PocketGull Project Authors; OFL 1.1`.
- **Aligned Font Revision Header (`head.fontRevision`)**: Exact 2.000 float match to eliminate Fontbakery version discrepancies.
- **UFO Source Synchronization**: Updated `versionMajor: 2` and `versionMinor: 0` across all 4 `.ufo` source directories.
- **Windows Bounding Box & Vertical Metrics**: Unified `OS/2.usWinAscent = 1230` and `OS/2.usWinDescent = 520` across the superfamily, eliminating Windows GDI clipping.
- **Specimen Legal Footer**: Replaced plain footer with a happy, humanist SIL OFL 1.1 footer explaining commercial/personal freedoms, Reserved Font Name (RFN) boundaries, and removing persistent floating overlay elements.
- **670nm Retinal Photobiomodulation (PBM) Integration**: Complete monochromatic ruby-red night mode overrides across all UI components and code drawers.

### Fixed
- **TrueType 2-Byte Word-Boundary Alignment**: Padded all glyph contours so that `loca[i] % 2 == 0`, passing 100% of Thomas Phinney forensic typefoundry checks.
- **W3C OpenType Sanitizer (OTS)**: 100% pass rate with zero warnings or fatals across all 16 TTF and WOFF2 binaries.
- **Fontbakery QA**: 711 automated checks passed with 0 FAILs and 0 FATALs across the proportional and monospace families.

## [1.0.0] - 2026-05-01

### Added
- **Original Inception (Physical Cardstock Felt-Marker)**:
  - Digitized physical cardstock hand-lettered by Phil Gear at GearArts into standardized 1000 UPM TrueType vectors with quadratic G2 curvature.
  - CERN Zenodo Archival DOI: [10.5281/zenodo.18879500](https://doi.org/10.5281/zenodo.18879500).
  - Baked core Latin, numerals, and punctuation onto a 1000 UPM em-square calibrated to Louise Sloan 5:1 optotypic legibility standards.
- **Institute for Safe Medication Practices (ISMP) Clinical Disambiguation**:
  - Slashed zero (`zero` / `cv08`) to prevent 10-fold dosing overdoses.
  - Curved lowercase l (`cv05`) to prevent confusion with numeral 1.
  - Serifed capital I (`ss02`) to disambiguate from lowercase l and pipe symbol.
  - Slashed Z (`cv11`) to prevent confusion with numeral 2 in handwriting and electronic prescriptions.
- **Louise Sloan 5:1 Visual Acuity Geometry**:
  - Calibrated all letter heights to 5 arcminutes and stroke / counter apertures to 1 arcminute at standard clinical viewing distances (55 cm near, 6 m far).
- **670nm Retinal Photobiomodulation (PBM) Dark Mode**:
  - Integrated high-contrast monochromatic dark mode eliminating high-energy blue photons (<500 nm) to safeguard night-shift clinician mitochondrial membrane potential and prevent circadian disruption.

